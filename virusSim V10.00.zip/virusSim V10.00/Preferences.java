
/**
 * @author (Luke Weston)
 * @version (1.0)
 */
public class Preferences
{
    public Preferences()
    {
        int[] vars = new int[] {30, 100, 100, 200, 1, 10, 10, 10};
    }
}
