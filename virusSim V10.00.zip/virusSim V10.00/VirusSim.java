
//@author Luke Weston
//* @version 10.0
import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
public class VirusSim {
    Scanner input = new Scanner(System.in);
    int population;
    int width;
    int height;
    int daysToRun;
    int peopleStartingInfected;
    int infectedTime;
    int immuneTime;
    int timesToRepeat;
    public VirusSim() throws Exception{
        System.out.println("note: the 'patient zero' will always be infected");
        System.out.println("note: infected patients cannot be reinfected, resetting their timer");
        System.out.println("note: enter -1 for default value, width cannot be less than 3.");
        String[] prompts = new String[] {"enter population", "enter width of world", "enter height of world", "enter days to run", "enter number of people to start as infected", 
                "enter how long people are infected for", "enter how long people are immune for after they are cured", "enter how many times to repeat"};
        int[] defaults = new int[] {30, 100, 100, 200, 1, 10, 10, 10};
        File file = new File ("output.txt");
        for(int z=0; z<=7; z--){
            System.out.println(prompts[z]);
            Preferences().vars[z] = input.nextInt();
        }
        String[][] world = new String[width][height];
        FileWriter writer = new FileWriter(file);
        for(int y=0; y<timesToRepeat; y++){
            int peopleInfected = 1;
            Person[] people = new Person[population];
            for(int i=0; i<population; i++){
                people[i] = new Person(width, height-1);
            }
            for(int q=0; q<peopleStartingInfected; q++){
                people[1].infected = true;
                people[1].amIPatientZero = true;
            }

            int daysRan = 0;
            while(daysRan < daysToRun){
                for(int i=0; i<population; i++){
                    //if (people[i].xPos >= width || people[i].xPos <= 0 || people[i].yPos >= height || people[i].yPos <= 0){
                    //    running = false;
                    //}

                    for(int k=0; k<width; k++){
                        for(int l=0; l<height; l++){
                            world[k][l] = "_";
                        }
                    }
                    if (people[i].direction == 0){
                        if(people[i].xPos + 1 >= width){
                            people[i].direction = 2;
                            people[i].xPos--;
                        }else{
                            people[i].xPos++;
                        }
                    }
                    if(people[i].direction == 1){
                        if(people[i].xPos - 1 <= 0){
                            people[i].direction = 0;
                            people[i].xPos++;
                        }else{
                            people[i].xPos--;
                        }
                    }
                    if (people[i].direction == 2){
                        if(people[i].yPos + 1 >= height){
                            people[i].direction = 3;
                            people[i].yPos--;
                        }else{
                            people[i].yPos++;
                        }
                    }else if(people[i].direction == 3){
                        if(people[i].yPos - 1 <= 0){
                            people[i].direction = 1;
                            people[i].yPos++;
                        }else{
                            people[i].yPos--;
                        }
                    }
                    //if (people[i].xPos >= width || people[i].xPos <= 0 || people[i].yPos >= height || people[i].yPos <= 0){
                    //  running = false;
                    //}
                    people[i].direction = ThreadLocalRandom.current().nextInt(0, 4);
                }
                for(int p=0; p<population; p++){
                    if(people[p].infected){
                        world[people[p].xPos][people[p].yPos] = "J"; 
                    }else{
                        world[people[p].xPos][people[p].yPos] = "A";
                    }
                    for(int u=0;u<population;u++){
                        if(people[p].xPos == people[u].xPos && people[p].yPos == people[u].yPos && people[p].infected &&  people[u].infected == false && people[u].infectedTimer == 0){
                            if(p != u){
                                people[u].infected = true;
                                peopleInfected++;
                                people[u].infectedTimer = infectedTime + 1;
                                //System.out.println("day " + daysRan + ", " + peopleInfected + " people infected");

                            }
                        }
                    }
                    if(people[p].infectedTimer > 0){
                        people[p].infectedTimer--;
                        if(people[p].infectedTimer == 0){
                            people[p].immuneTimer = immuneTime + 1;
                        }
                    }
                    if(people[p].infectedTimer > 0){
                        people[p].immuneTimer--;
                    }
                }

                // for(int h=0; h<width; h++){
                // for(int g=0; g<height; g++){
                // System.out.print(world[h][g] + " ");
                // }
                // System.out.print("\n");
                // }
                // System.out.print("\n");
                // System.out.print("\n");
                daysRan++;

            }
            System.out.print("\n");
            System.out.println("day " + daysRan + ", " + peopleInfected + " people infected");
            writer.write(daysRan + " " + peopleInfected + " " + daysRan/peopleInfected + "\n");

        }
        writer.write("daysRan peopleInfected daysRan/peopleInfected" + "\n");
        writer.flush();
        writer.close();
    }
}